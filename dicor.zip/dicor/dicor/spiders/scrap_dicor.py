import scrapy
from ..items import DicorItem

#Spider to crawl website
class ScrapDicorSpider(scrapy.Spider):
    #spider name
    name = 'scrap_dicor'
    #scrapping url
    start_urls = ['https://www.dior.com/en_us/']

    def parse(self, response):
        items=DicorItem()
        #search for nav buttons
        nav_icons = response.css("a.navigation-tab-title::attr(href)").extract()
        for nav_icon in nav_icons:
            #follow nav links
            yield response.follow(nav_icon,callback=self.find_item)

    def find_item(self,response):
        #get products link
        link=response.css("a.product-link::attr(href)").extract()
        #get product images
        image=response.css("div.product-image div.image img::attr(src)").extract()
        yield {'link':link,'image':image}
        
        
