# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class DicorItem(scrapy.Item):
    # define the fields for your item here like:
    link = scrapy.Field()
    image = scrapy.Field()
    title = scrapy.Field()
    subtitle = scrapy.Field()
    price = scrapy.Field()
    
